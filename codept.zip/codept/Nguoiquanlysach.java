/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package QLSach;

/**
 *
 * @author TramAnh
 */
public class Nguoiquanlysach extends Nhanvien {
        private float phucap;
    Nhanvien ll;
    public Nguoiquanlysach (){
        
    }
    public Nguoiquanlysach (float phucap,String NhanVienID,String Ngaybatdaulam,
            boolean Lamviectheothang,float Sogiolamviec,int songaylamviec,float tienthuong,
            float luongcoban ){
        super(NhanVienID,Ngaybatdaulam,Lamviectheothang,Sogiolamviec,songaylamviec,tienthuong,luongcoban);
        this.phucap=phucap;
    }
    public float tienluong (){
        if(ll.getLamviectheothang() == true) ll.setluonglamviec();
        return ll.getluonglamviec();
    }
    public void phucap (){
        ll.getsongaylamviec();
        phucap=ll.tienthuong();
    }
    @Override
    public float tinhluong(){
        return tienluong()*phucap+tienluong();
    }
    
     public void nhapthongtin (){
         ll.nhapthongtin();
    }       

    @Override
    public void input() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void output() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}

