package QLSach;


import java.util.Scanner;


public abstract class Nhanvien extends ConNguoi{
    
//thienphuc
    private String NhanVienID;
    private String Ngaybatdaulam;
    private boolean Lamviectheothang;
    private float Sogiolamviec;
    private int songaylamviec;
    private float tienthuong;
    private float luongcoban;
    ConNguoi ll;
    public Nhanvien (){
        
    }
    public Nhanvien (String NhanVienID,String Ngaybatdaulam,boolean Lamviectheothang,
    float Sogiolamviec,int songaylamviec,float tienthuong,float luongcoban){
        this.NhanVienID=NhanVienID;
        this.Lamviectheothang=Lamviectheothang;
        this.Ngaybatdaulam=Ngaybatdaulam;
        this.Sogiolamviec=Sogiolamviec;
        this.luongcoban=luongcoban;
        this.songaylamviec=songaylamviec;
        this.tienthuong=tienthuong;
    }
    public Nhanvien(String NhanVienID,String HoTen,String CMND,
            String SDT,String DiaChi,String NgaySinh,String GioiTinh){
         super(HoTen,CMND,SDT,DiaChi,NgaySinh,GioiTinh);
         this.NhanVienID=NhanVienID;
    }
           
    public String getNhanvienID (String NhanvienID){
        return NhanvienID;
    }
    public void setNhanvienID (String NhanVienID)
    {
        this.NhanVienID=NhanVienID;
    }
    public String getNgaybatdaulamviec (){
        return Ngaybatdaulam;
    }
    public void setNgaybatdaulamviec(String Ngaybatdaulam){
        Scanner sc=new Scanner (System.in);
        System.out.println("Nhap ngay bat dau lam chinh thuc");
        int ngay,thang,nam;
            System.out.println("nhap ngay");
            ngay=sc.nextInt();
            System.out.println("nhap thang");
            thang=sc.nextInt();
            System.out.println("nhap nam");
            nam=sc.nextInt();
            while(ngay < 0){
                System.out.println("nhap lai ngay: ");
                ngay=sc.nextInt();
            }
            while (thang < 0){
                System.out.println("nhap lai thang: ");
                thang=sc.nextInt();
            }
            while (nam < 0){
                System.out.println("nhap lai nam");
                nam=sc.nextInt();
            }
            Ngaybatdaulam=Integer.toString(ngay + thang + nam);
        this.Ngaybatdaulam=Ngaybatdaulam;
    }
    public boolean getLamviectheothang(){
        return Lamviectheothang;
    }
    public void setLamviectheothang(boolean Lamviectheothang){
        Scanner sc=new Scanner (System.in);
        System.out.println("lam viec theo gio hay theo thang");
        System.out.println("Chon: 1.Lamtheogio   2.Lamtheothang");
        int x=sc.nextInt();
        if(x == 1) this.Lamviectheothang=false;
        else this.Lamviectheothang=true;
    }
    public float getsogiolamviec (){
        return Sogiolamviec;
    }
    public void setsogiolamviec(float Sogiolamviec){
        Scanner sc=new Scanner (System.in);
        System.out.println("nhap so gio lam viec: ");
        do{
            Sogiolamviec=sc.nextFloat();
            if(Sogiolamviec < 0) System.out.println("nhap lai: ");
            else break;
        }while (true);
        this.Sogiolamviec=Sogiolamviec;
    }
    public int getsongaylamviec (){
        return songaylamviec;
    }
    public void setsongaylamviec(int songaylamviec){
        Scanner sc=new Scanner (System.in);
        System.out.println("nhap so ngay lam viec: ");
        do{
            songaylamviec=sc.nextInt();
            if(songaylamviec < 0) System.out.println("nhap lai: ");
            else break;
        }while (true);
        this.songaylamviec=songaylamviec;
    }
    public abstract float tinhluong ();
    public float getluonglamviec (){
        return luongcoban;
    }
    public void setluonglamviec (){
        Scanner sc=new Scanner (System.in);
        int x;
        System.out.println("chuc vu lam viec: ");
        System.out.println("Moi ban chon: \n 1: Nguoi dung quay \n "
                + "2: Bao ve \n 3: Quan ly sach ");
        if(Lamviectheothang == true){
            do{
             x=sc.nextInt();
            switch(x){
            case 1: luongcoban=4000000;
            case 2: luongcoban=3500000;
            case 3: luongcoban=5000000;
            }
            if(x != 1 || x!= 2 || x!= 3) System.out.println("moi nhap lai");
            else break;
            }while (true);
        }
        else {
             do{
             x=sc.nextInt();
            switch(x){
            case 1: luongcoban=20000;
            case 2: luongcoban=15000;
            case 3: luongcoban=30000;
            }
            if(x != 1 || x!= 2 || x!= 3) System.out.println("moi nhap lai");
            else break;
            }while (true);
        }
            
        this.luongcoban=luongcoban;
        }
    
    public float tienthuong (){
        switch(songaylamviec){
            case 30: return luongcoban*0.3f; 
            case 27: return luongcoban*0.1f;
            default: return luongcoban;
        }
    }
    public void nhapthongtin(){
        Scanner sc=new Scanner(System.in);
         System.out.println("nhap thong tin");
         System.out.println("Nhap ho ten: ");
         String node=sc.nextLine();
         ll.setHoTen(node);
         System.out.println("Nhap so chung minh tu");
         node=sc.nextLine();
         ll.setCMND(node);
         System.out.println("Nhap so dien thoai: ");
         node=sc.nextLine();
         ll.setSDT(node);
         System.out.println("Nhap dia chi");
         node=sc.nextLine();
         ll.setDiaChi(node);
         System.out.println("Nhap ngay sinh");
         node=sc.nextLine();
         ll.setNgaySinh(node);
         System.out.println();
         System.out.println("nhap ma nhan vien: ");
         String NhanvienID;
         NhanvienID=sc.nextLine();
         setNhanvienID(NhanvienID);
         System.out.println("Lua chon kieu hop dong lam viec");
         setLamviectheothang(Lamviectheothang);
         }
}